import requests


def get_simples(url):
    r = requests.get(url)
    return r


def get_params(url, p):
    r = requests.get(url, params=p)
    return r


def post(url, data):
    # body => json, objeto python -> json=
    # params => parametros visiveis NÃO É SEGURO FAZER ISSO -> params=
    # data => qualquer coisa
    r = requests.post(url, json=data)
    return r


url_get = "http://localhost/Projeto/Dashboard/api.php"
url_post = "http://localhost/Projeto/Dashboard/api.php"


# http://localhost/Projeto/Dashboard/api.php?search=matheus
response = get_params(url_get, {"search": "lucas"})
print(response.json())
