<form method="post" action="" id="mail_form">
    <div id="newsletter"> 

        <div class="newslink">
            <input type="hidden" name="submit_newsletter" />
            <a href="criarevento.php" onClick="document.getElementById('mail_form').submit();">ENVIAR</a>
        </div>
    </div>
</form>