<html lang="auto" class=""><head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Global Access</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">


  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700
  ,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,
  600,600i,700,700i" rel="stylesheet">

 
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link href="assets/css/style.css" rel="stylesheet">


<link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"><link type="text/css" rel="stylesheet" charset="UTF-8" href="https://translate.googleapis.com/translate_static/css/translateelement.css"></head>

<body data-aos-easing="ease-in-out" data-aos-duration="1000" data-aos-delay="0">

  <header id="header" class="fixed-top d-flex align-items-center header-transparent">
    <div class="container d-flex align-items-center justify-content-between">

      <div class="logo">
        <h1><a href="index.php"><font style="vertical-align: inherit;"><img src="assets/img/logo.png" alt=""><font style="vertical-align: inherit;">Acesso Global</font></font></a></h1>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Casa</font></font></a></li>
          <li><a class="nav-link scrollto" href="#about"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sobre</font></font></a></li>
          <li><a class="nav-link scrollto" href="#services"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Serviços</font></font></a></li>
          <li><a class="nav-link scrollto" href="#contact"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contato</font></font></a></li>
          <li><a class="nav-link scrollto " href="http://10.19.1.232:8080/Projeto/Login/index.php"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Conecte-se</font></font></a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header>


  <section id="hero" class="d-flex flex-column justify-content-end align-items-center">
    <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">


      <div class="carousel-item active">
        <div class="carousel-container">
          <h2 class="animate__animated animate__fadeInDown">Conhecimento Internacional </h2>
          <h2 class="animate__animated animate__fadeInDown">Constantemente Atualizado </h2>
          <h2 class="animate__animated animate__fadeInDown">Projeto em mais de 10 países </h2>

          <p class="animate__animated fanimate__adeInUp"></p>
          <a href="#about" class="btn-get-started animate__animated animate__fadeInUp scrollto"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Consulte Mais informação</font></font></a>
        </div>
      </div>

      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bx bx-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bx bx-chevron-right" aria-hidden="true"></span>
      </a>

    </div>

    <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
      <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
      </path></defs>
      <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
      </use></g>
      <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
      </use></g>
      <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
      </use></g>
    </svg>

  </section>

  <main id="main">

    <section id="about" class="about">
      <div class="container">

        <div class="section-title aos-init aos-animate" data-aos="zoom-out">
          <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sobre</font></font></h2>
          <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Quem nós somos</font></font></p>
        </div>

        <div class="row content aos-init aos-animate" data-aos="fade-up">
          <div class="col-lg-6">
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
A GA, ajuda seus clientes a terem sucesso em ambientes de alta complexidade e perigosos, lhes permitindo controlar e mitigar os riscos por meio de um conjunto de soluções feitos sob medida para você.</font></font></p>
            <ul>
              <li><i class="ri-check-double-line"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Se o distrito escolar está trabalhando para atingir seus objetivos</font></font></li>
              <li><i class="ri-check-double-line"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">A dor condenará no prazer</font></font></li>
              <li><i class="ri-check-double-line"></i><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Se o distrito escolar está trabalhando para atingir seus objetivos</font></font></li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Fundada em Israel há 20 anos por especialistas multidisciplinares com altos cargos na Agência e Segurança de Israel (ISA – Israel’ Security Agency) e das Forças de Defesa de Israel (IDF – Israel Defense Forces), a GA tem orgulho em contar com profissionais altamente qualificados com anos de experiência em projetos de segurança e proteção, inteligência corporativa, compliance, investigação de fraudes e terceirização de canal de denúncias.

</font><font style="vertical-align: inherit;">Mas a dor no filme é irrecusável para condenar, no prazer quer fugir da dor de ser cillum na dor, sem resultado. </font><font style="vertical-align: inherit;">São as exceções que os cegos anseiam, não vêem, são eles que abandonam suas responsabilidades à culpa que aplaca as agruras da alma.
            </font></font></p>
            <a href="#" class="btn-learn-more"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Saber mais</font></font></a>
          </div>
        </div>

      </div>
    </section>


    <section id="features" class="features">
      <div class="container">

        <ul class="nav nav-tabs row d-flex">
          <li class="nav-item col-3 aos-init aos-animate" data-aos="zoom-in">
            <a class="nav-link show" data-bs-toggle="tab" href="#tab-1">
              <i class="ri-gps-line"></i>
              <h4 class="d-none d-lg-block">Transparência</h4>
            </a>
          </li>
          <li class="nav-item col-3 aos-init aos-animate" data-aos="zoom-in" data-aos-delay="100">
            <a class="nav-link" data-bs-toggle="tab" href="#tab-2">
              <i class="ri-body-scan-line"></i>
              <h4 class="d-none d-lg-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SOLUÇÕES CUSTOMIZADAS</font></font></h4>
            </a>
          </li>
          <li class="nav-item col-3 aos-init aos-animate" data-aos="zoom-in" data-aos-delay="200">
            <a class="nav-link" data-bs-toggle="tab" href="#tab-3">
              <i class="ri-sun-line"></i>
              <h4 class="d-none d-lg-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GESTÃO DE RISCOS 360°</font></font></h4>
            </a>
          </li>
          <li class="nav-item col-3 aos-init aos-animate" data-aos="zoom-in" data-aos-delay="300">
            <a class="nav-link active" data-bs-toggle="tab" href="#tab-4">
              <i class="ri-store-line"></i>
              <h4 class="d-none d-lg-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">EXPERIÊNCIA INTERNACIONAL</font></font></h4>
            </a>
          </li>
        </ul>

        <div class="tab-content aos-init aos-animate" data-aos="fade-up">
          <div class="tab-pane show" id="tab-1">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Transparência</font></font></h3>
                <p class="fst-italic"><font style="vertical-align: inherit;"></font></p>
                <ul>
                  
                  
                  
                </ul>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Somos comprometidos com relações fundamentadas na confiabilidade pessoal e profissional, preservamos o sigilo de todos os dados que nos são disponibilizados por meio da confiança estabelecida. Apresentamos resultados precisos e evitamos despesas desnecessárias durante todo projeto.</font><font style="vertical-align: inherit;">Aqueles que anseiam por negros são a exceção, eles não veem, são culpados por quem abandona suas responsabilidades, essa é a dificuldade que amolece suas mentes
                </font></font></p>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-1.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-2">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">SOLUÇÕES CUSTOMIZADAS</font></font></h3>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Você como nosso cliente é único, por isso nossas soluções são customizadas para suas necessidades e seus objetivos. Estamos comprometidos em entender sua realidade e necessidade antes de apresentarmos nossas soluções exclusivas.</font></font></p>
                
                
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-2.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-3">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">GESTÃO DE RISCOS 360°</font></font></h3>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Nossas soluções em segurança, mitigação de riscos e prevenção de perdas atuam em todo o ciclo do risco, desde sua detecção e análise, até a apresentação das soluções e a implementação, em uma visão 360°. A integração de todos os serviços e soluções oferecidas por nós, leva para você tranquilidade e confiança de que as melhores práticas do mundo estão sob seu controle.</font></font></p>
                
                
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-3.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
          <div class="tab-pane active" id="tab-4">
            <div class="row">
              <div class="col-lg-6 order-2 order-lg-1 mt-3 mt-lg-0">
                <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">EXPERIÊNCIA INTERNACIONAL</font></font></h3>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Profissionais oriundos de unidades especiais do governo de Israel (ISA  – Israel Security Agency / Shin Bet) e do exército israelense (IDF – Israel Defense Forces), fazem parte  do nosso time de especialistas com vastas experiências nos lugares mais complexos e perigosos do mundo. Estamos em constante atualização com as metodologias e tecnologias mais adequadas nacional e internacionalmente. Nosso objetivo é estabelecer a segurança permanente, evitando danos que levam a perdas e impactos negativos para você, sua família e seus negócios.</font></font></p>
                
                <ul>
                  
                  
                  
                </ul>
              </div>
              <div class="col-lg-6 order-1 order-lg-2 text-center">
                <img src="assets/img/features-4.png" alt="" class="img-fluid">
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>


    <section id="cta" class="cta">
      <div class="container">

        <div class="row aos-init aos-animate" data-aos="zoom-out">
          <div class="col-lg-9 text-center text-lg-start">
            <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">MAIS QUE SEGURANÇA</font></font></h3>
            <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Acreditamos em pessoas visionárias e íntegras como você, que faz todo o possível em busca de resultados.
Mesmo suas incertezas, dúvidas e dificuldades, encontram a superação ao longo do caminho e continuam
acreditando que seu sucesso será a alavanca de crescimento não somente para você, mas também para
para a sociedade e a economia em que está inserido.</font><font style="vertical-align: inherit;">Evitamos que causas hostis prejudiquem suas metas pessoais e organizacionais a qualquer momento.
“Juntos somos mais que segurança”</font></font></p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle" href="#"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Chamada à ação</font></font></a>
          </div>
        </div>

      </div>
    </section>


    <section id="services" class="services">
      <div class="container">

        <div class="section-title aos-init aos-animate" data-aos="zoom-out">
          <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Serviços</font></font></h2>
          <p>...</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left">
              <div class="icon"><i class="bi bi-briefcase" style="color: #ff689b;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5 mt-md-0">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left" data-aos-delay="100">
              <div class="icon"><i class="bi bi-book" style="color: #e9bf06;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-5 mt-lg-0 ">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left" data-aos-delay="200">
              <div class="icon"><i class="bi bi-card-checklist" style="color: #3fcdc7;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left" data-aos-delay="300">
              <div class="icon"><i class="bi bi-binoculars" style="color:#41cf2e;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left" data-aos-delay="400">
              <div class="icon"><i class="bi bi-globe" style="color: #d6ff22;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mt-5">
            <div class="icon-box aos-init aos-animate" data-aos="zoom-in-left" data-aos-delay="500">
              <div class="icon"><i class="bi bi-clock" style="color: #4680ff;"></i></div>
              <h4 class="title"><a href=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></a></h4>
              <p class="description"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">...</font></font></p>
            </div>
          </div>
        </div>

      </div>
    </section>

          

    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title aos-init aos-animate" data-aos="zoom-out">
          <h2><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Contato</font></font></h2>
          <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Entre em contato conosco</font></font></p>
        </div>

        <div class="row mt-5">

          <div class="col-lg-4 aos-init" data-aos="fade-right">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Localização:</font></font></h4>
                <p>SBN Quadra 1- Bloco C Ed. Roberto Simonsen - Asa Norte, DF, 70040-903</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">E-mail:</font></font></h4>
                <p>GlobalAccess@example.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ligar:</font></font></h4>
                <p>(61) 3317-9000</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0 aos-init" data-aos="fade-left">

          </div>

        </div>

      </div>
    </section>

  </main>


  <footer id="footer">
    <div class="container">
      <h3><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Acesso Global</font></font></h3>
      <p>“Somos seres humanos apaixonados por segurança.
        Somos profissionais de segurança apaixonados por seres humanos”..</p>
      <div class="social-links">
        <a href="https://www.facebook.com/gaadvising/" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://www.linkedin.com/company/gaadvising/" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>


  <script src="assets/js/main.js"></script>

<!-- Code injected by live-server -->
<script type="text/javascript">
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>

<!-- Code injected by live-server -->
<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Tradutor"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texto original</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Sugerir uma tradução melhor</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><script type="text/javascript">
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div><!-- Code injected by live-server -->
<script type="text/javascript">
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script><!-- Code injected by live-server -->
<script type="text/javascript">
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script><!-- Code injected by live-server -->
<div id="goog-gt-tt" class="skiptranslate" dir="ltr"><div style="padding: 8px;"><div><div class="logo"><img src="https://www.gstatic.com/images/branding/product/1x/translate_24dp.png" width="20" height="20" alt="Google Tradutor"></div></div></div><div class="top" style="padding: 8px; float: left; width: 100%;"><h1 class="title gray">Texto original</h1></div><div class="middle" style="padding: 8px;"><div class="original-text"></div></div><div class="bottom" style="padding: 8px;"><div class="activity-links"><span class="activity-link">Sugerir uma tradução melhor</span><span class="activity-link"></span></div><div class="started-activity-container"><hr style="color: #CCC; background-color: #CCC; height: 1px; border: none;"><div class="activity-root"></div></div></div><div class="status-message" style="display: none;"></div></div><script type="text/javascript">
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script><div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body></html>